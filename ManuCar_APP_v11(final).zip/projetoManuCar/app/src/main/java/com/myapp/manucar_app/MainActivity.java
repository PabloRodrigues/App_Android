package com.myapp.manucar_app;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;
import com.myapp.manucar_app.ui.allServs.ListServsFragment;
import com.myapp.manucar_app.ui.combustivel.CombustivelFragment;
import com.myapp.manucar_app.ui.despesas.DespesasFragment;
import com.myapp.manucar_app.ui.graficos.GraficosFragment;
import com.myapp.manucar_app.ui.oleo.OleoFragment;
import com.myapp.manucar_app.ui.resumo.ResumoFragment;
import com.myapp.manucar_app.ui.seguro.SeguroFragment;
import com.myapp.manucar_app.ui.servicos.ServicosFragment;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{

    int id_usuario;
    int id_veiculo;
    String loginIT;
    String senhaIT;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        BancoDados bancoDados = new BancoDados(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setTitle("ManuCar");
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);

        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);


//RECUPERA  INFORMAÇÕES DA INTENT MAIN ATRAVES DO BUNDLES.------------------------------------------------------------------------
        Intent intentMenu = getIntent();
        Bundle extrasMenu = intentMenu.getExtras();

        id_usuario = extrasMenu.getInt("id_usuario");
        id_veiculo = extrasMenu.getInt("id_veiculo");
        loginIT = extrasMenu.getString("loginIT2");
        senhaIT = extrasMenu.getString("senhaIT2");

//RECUPERA  INFORMAÇÕES DA INTENT MAIN ATRAVES DO BUNDLES.------------------------------------------------------------------------

        TextView nome_usuario_txtView = headerView.findViewById(R.id.nome_usuario_txtView);
        TextView email_usuario_txtView = headerView.findViewById(R.id.email_usuario_txtView);

        Usuario usuario1 = bancoDados.selecionarUsuario(loginIT,senhaIT);
        String nome_user = usuario1.getNome_usuario();
        String email_user = usuario1.getEmail_usuario();


        if (nome_user!= null && email_user!=null){

            nome_usuario_txtView.setText(nome_user);
            email_usuario_txtView.setText(email_user);
        }
    }




    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){

        int id = item.getItemId();

        if (id == R.id.action_settings){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item){
        int id = item.getItemId();
        Fragment fragment;

        if (id == R.id.nav_combustivel) {

            fragment = new ListServsFragment();
            //fragment = new CombustivelFragment();
         //==============================================================================================
            int id_cat_servico = 1;
            Bundle bundle = new Bundle();
            bundle.putInt("id_cat_servico",id_cat_servico);
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();

        }else if (id == R.id.nav_oleo){
            fragment = new ListServsFragment();
            //fragment = new OleoFragment();
        //==============================================================================================
            int id_cat_servico = 4;
            Bundle bundle = new Bundle();
            bundle.putInt("id_cat_servico",id_cat_servico);
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();

        }else if (id == R.id.nav_servicos){
            fragment = new ListServsFragment();
            //fragment = new ServicosFragment();
        //==============================================================================================
            int id_cat_servico = 2;
            Bundle bundle = new Bundle();
            bundle.putInt("id_cat_servico",id_cat_servico);
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();

        }else if (id == R.id.nav_despesas){
            fragment = new ListServsFragment();
            //fragment = new DespesasFragment();
        //==============================================================================================
            int id_cat_servico = 3;
            Bundle bundle = new Bundle();
            bundle.putInt("id_cat_servico",id_cat_servico);
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();

        }else if (id == R.id.nav_seguro){
            fragment = new ListServsFragment();
            //fragment = new SeguroFragment();
        //==============================================================================================
            int id_cat_servico = 5;
            Bundle bundle = new Bundle();
            bundle.putInt("id_cat_servico",id_cat_servico);
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();

        }else if (id == R.id.nav_resumo){
            fragment = new ResumoFragment();
        //==============================================================================================
            Bundle bundle = new Bundle();
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();

        }else if (id == R.id.nav_graficos){
            fragment = new GraficosFragment();
        //==============================================================================================
            Bundle bundle = new Bundle();
            bundle.putInt("id_usuario", id_usuario);
            bundle.putInt("id_veiculo", id_veiculo);
            fragment.setArguments(bundle);
        //==============================================================================================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        //retorna o drawer
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);

            // Independente do fragment que está, retorna pra activity
        } else if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            //faz voltar pra activity e limpa o popBackStack
            getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        //fecha a aplicação, aqui você pode fazer voltar para alguma activity
        else {
            super.onBackPressed();
        }
    }

/*
    public void onBackPressed(){
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }*/

}