package com.myapp.manucar_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaPrincipalActivity extends AppCompatActivity implements View.OnClickListener {

    public Button btn_login_main;
    public Button btn_registro_main;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        btn_login_main = findViewById(R.id.LOGIN_button);
        btn_login_main.setOnClickListener(this);
        btn_registro_main = findViewById(R.id.REGISTRE_button2);
        btn_registro_main.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        //FUNÇÃO DE CLIQUES DOS BOTÕES
        switch(v.getId()) {

            case R.id.LOGIN_button:
               Intent log = new Intent(this, TelaLoginActivity.class);
               startActivity(log);
                break;

            case R.id.REGISTRE_button2:
                Intent reg = new Intent(this, TelaRegistroActivity.class);
                startActivity(reg);
                break;
        }


    }
}
