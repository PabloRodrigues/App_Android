package com.myapp.manucar_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class TelaLoginActivity extends AppCompatActivity implements View.OnClickListener{
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public Button entrar_login_button;
    private EditText senha_editText;
    private EditText login_editText;

    private ConstraintLayout login_tela_main;

    BancoDados db = new BancoDados(this);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        senha_editText      = findViewById(R.id.senha_editText);
        login_editText      = findViewById(R.id.login_editText);

        login_tela_main = (ConstraintLayout) findViewById(R.id.login_tela_main);

        entrar_login_button = findViewById(R.id.entrar_login_button);
        entrar_login_button.setOnClickListener(this);

    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void onClick(View v) {
        //FUNÇÃO DE CLIQUES NOS BOTÕES, VALIDA LOGIN

        switch(v.getId()) {

            case R.id.entrar_login_button:

                final String login =  login_editText.getText().toString();
                final String senha =  senha_editText.getText().toString();

                if(login.isEmpty()){
                    login_editText.setError("Este campo é obrigatorio");
                }else if(senha.isEmpty()) {
                    senha_editText.setError("Este campo é obrigatorio");
                }else if (db.validaSenha(senha, login)==true){

                    Bundle extrasLogin = new Bundle();
                    extrasLogin.putString("LOGIN",login);
                    extrasLogin.putString("SENHA",senha);

                    Intent intentLogin = new Intent(getApplicationContext(), TelaMenuActivity.class);
                    intentLogin.putExtras(extrasLogin);
                    startActivity(intentLogin);

                    Toast.makeText(TelaLoginActivity.this,"logado com sucesso",Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                   // Intent it = new Intent(TelaLoginActivity.this, TelaPrincipalActivity.class);
                    // startActivity(it);
                    Toast.makeText(TelaLoginActivity.this,"Usuario ou senha errado, tente novamente!",Toast.LENGTH_SHORT).show();
                }

                break;

        }

        };

    }