package com.myapp.manucar_app;

public class Fabricante {

    int id_fabricante;
    String nome_fab;


    public Fabricante() {
    }


    public Fabricante(int id_fabricante, String nome_fab) {
        this.id_fabricante = id_fabricante;
        this.nome_fab = nome_fab;
    }
    public Fabricante(String nome_fab) {
        this.nome_fab = nome_fab;
    }

    public int getId_fabricante() {
        return id_fabricante;
    }

    public void setId_fabricante(int id_fabricante) {
        this.id_fabricante = id_fabricante;
    }


    public String getNome_fab() {
        return nome_fab;
    }

    public void setNome_fab(String nome_fab) {
        this.nome_fab = nome_fab;
    }

    @Override
    public String toString() {
        return  nome_fab ;
    }
}
