package com.myapp.manucar_app;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServicosRealizados {

    int id_servicoRealizado;
    int dataServ;
    float valorUnitario;
    float valorTotal;
    float qtdServ;
    int odometroServ;
    String razaoSocialServ;
    int dataValidadeSeguro;
    String nomeServ;
    int id_servico;
    int id_veiculo;

 //   String dataString = String.valueOf(dataServ).substring(6,8)+"/"+String.valueOf(dataServ).substring(4,6)+"/"+String.valueOf(dataServ).substring(0,4);
//Transformo a data YYYYmmDD(int) em DD/MM/YYYY(String)


    public ServicosRealizados() {
    }

    public ServicosRealizados(String nomeServ, float valorTotal) {
        this.nomeServ = nomeServ;
        this.valorTotal = valorTotal;
    }

    public ServicosRealizados(int id_servicoRealizado, String nomeServ, int dataServ, float valorUnitario, float valorTotal, float qtdServ) {
        this.id_servicoRealizado = id_servicoRealizado;
        this.nomeServ = nomeServ;
        this.dataServ = dataServ;
        this.valorUnitario = valorUnitario;
        this.valorTotal = valorTotal;
        this.qtdServ = qtdServ;
    }

    public ServicosRealizados(int dataServ, float valorUnitario, float valorTotal,float qtdServ, int odometroServ, String razaoSocialServ, int dataValidadeSeguro, int id_servico, int id_veiculo) {
        this.dataServ = dataServ;
        this.valorUnitario = valorUnitario;
        this.valorTotal = valorTotal;
        this.qtdServ = qtdServ;
        this.odometroServ = odometroServ;
        this.razaoSocialServ = razaoSocialServ;
        this.dataValidadeSeguro = dataValidadeSeguro;
        this.id_servico = id_servico;
        this.id_veiculo = id_veiculo;
    }

    public ServicosRealizados(int dataServ, float valorUnitario, float valorTotal, float qtdServ, int odometroServ, String razaoSocialServ, int id_servico, int id_veiculo) {
        this.dataServ = dataServ;
        this.valorUnitario = valorUnitario;
        this.valorTotal = valorTotal;
        this.qtdServ = qtdServ;
        this.odometroServ = odometroServ;
        this.razaoSocialServ = razaoSocialServ;
        this.id_servico = id_servico;
        this.id_veiculo = id_veiculo;
    }

    @Override
    public String toString() {
        return  "Data: " + String.valueOf(dataServ).substring(6,8)+"/"+String.valueOf(dataServ).substring(4,6)+"/"+String.valueOf(dataServ).substring(0,4)+
                " - Serviço: " + nomeServ +
                " - Valor unt.: " + valorUnitario +
                " - Qtd: " + qtdServ+
                " - Valor total: " + valorTotal;
    }

    public void setId_servicoRealizado(int id_servicoRealizado) {
        this.id_servicoRealizado = id_servicoRealizado;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public void setDataServ(int dataServ) {
        this.dataServ = dataServ;
    }

    public void setValorUnitario(float valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public void setQtdServ(float qtdServ) {
        this.qtdServ = qtdServ;
    }

    public void setOdometroServ(int odometroServ) {
        this.odometroServ = odometroServ;
    }

    public void setRazaoSocialServ(String razaoSocialServ) {
        this.razaoSocialServ = razaoSocialServ;
    }

    public void setDataValidadeSeguro(int dataValidadeSeguro) {
        this.dataValidadeSeguro = dataValidadeSeguro;
    }

    public void setNomeServ(String nomeServ) {
        this.nomeServ = nomeServ;
    }

    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    public void setId_veiculo(int id_veiculo) {
        this.id_veiculo = id_veiculo;
    }

    public String getNomeServ() {
        return nomeServ;
    }

    public int getId_servicoRealizado() {
        return id_servicoRealizado;
    }

    public int getDataServ() {
        return dataServ;
    }

    public float getValorUnitario() {
        return valorUnitario;
    }

    public float getQtdServ() {
        return qtdServ;
    }

    public int getOdometroServ() {
        return odometroServ;
    }

    public String getRazaoSocialServ() {
        return razaoSocialServ;
    }

    public int getDataValidadeSeguro() {
        return dataValidadeSeguro;
    }

    public int getId_servico() {
        return id_servico;
    }

    public int getId_veiculo() {
        return id_veiculo;
    }
}
