package com.myapp.manucar_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;


public class TelaRegistroActivity extends AppCompatActivity implements View.OnClickListener {
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private EditText CAD_SENHA_editText;
    private EditText CAD_NOME_editText2;
    private EditText CAD_EMAIL_editText;
    private EditText CAD_LOGIN_editText3;
    public Button btn_cadastrar_main;
    private ConstraintLayout registro_tela_main;

    BancoDados db = new BancoDados(this);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_registro);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        CAD_SENHA_editText = (EditText) findViewById(R.id.CAD_SENHA_editText);
        CAD_EMAIL_editText = (EditText) findViewById(R.id.CAD_EMAIL_editText);
        CAD_NOME_editText2 = (EditText) findViewById(R.id.CAD_NOME_editText2);
        CAD_LOGIN_editText3 = (EditText) findViewById(R.id.CAD_LOGIN_editText3);

        registro_tela_main = (ConstraintLayout) findViewById(R.id.registro_tela_main);

        btn_cadastrar_main = findViewById(R.id.CAD_CADASTRAR_button);
        btn_cadastrar_main.setOnClickListener(this);


    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////



    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean isCampoVazio(String valor) {

        boolean resultado = (TextUtils.isEmpty(valor) || valor.trim().isEmpty());
        return resultado;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean isEmailValido(String email) {

        boolean resultado = (!isCampoVazio(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
        return resultado;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onClick(View v) {

        switch(v.getId()) {

            case R.id.CAD_CADASTRAR_button:

                String nome     = CAD_NOME_editText2.getText().toString();
                String email    = CAD_EMAIL_editText.getText().toString();
                String CPF      = "1";
                String login    = CAD_LOGIN_editText3.getText().toString();
                String senha    = CAD_SENHA_editText.getText().toString();

                if(login.isEmpty() || login.length()<6){
                    CAD_LOGIN_editText3.setError("Este campo é obrigatorio (6 digitos)");
                }else if(senha.isEmpty()|| senha.length()<6){
                    CAD_SENHA_editText.setError("Este campo é obrigatorio (6 digitos)");
                }else if(nome.isEmpty()){
                    CAD_NOME_editText2.setError("Este campo é obrigatorio");
                }else if(isEmailValido(email) != true){
                    CAD_EMAIL_editText.setError("Campo invalido ou em branco");
                }else {
                    db.addUsuario(new Usuario(nome,CPF,email, login, senha));
                    Toast.makeText(TelaRegistroActivity.this,"Usuario criado com sucesso!",Toast.LENGTH_LONG).show();
                    Intent it = new Intent(TelaRegistroActivity.this, TelaPrincipalActivity.class);
                    startActivity(it);
                    finish();
                }

                break;

        };
    }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////


}



