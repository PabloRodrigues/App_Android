package com.myapp.manucar_app.ui.allServs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.myapp.manucar_app.BancoDados;
import com.myapp.manucar_app.R;
import com.myapp.manucar_app.ServicosRealizados;
import com.myapp.manucar_app.ui.combustivel.CombustivelFragment;
import com.myapp.manucar_app.ui.despesas.DespesasFragment;
import com.myapp.manucar_app.ui.oleo.OleoFragment;
import com.myapp.manucar_app.ui.seguro.SeguroFragment;
import com.myapp.manucar_app.ui.servicos.ServicosFragment;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class ListServsFragment extends Fragment{

    int id_usuario;
    int id_veiculo;
    int id_cat_servico;


    private ListView listaListView;
    private ArrayList<ServicosRealizados> lista;
    private ArrayAdapter<ServicosRealizados> listaArrayAdapter;

    BancoDados bancoDados;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_list_serv, container, false);

        bancoDados = new BancoDados(getContext());


//recupera os dados passados por argumentos da mainActivity===========================================================
        Bundle bundle = getArguments();
        if (bundle != null) {
            id_usuario = bundle.getInt("id_usuario");
            id_veiculo = bundle.getInt("id_veiculo");
            id_cat_servico = bundle.getInt("id_cat_servico");
        }
//recupera os dados passados por argumentos da mainActivity===========================================================

        final TextView all_serv_textView = root.findViewById(R.id.all_serv_textView);
        Button adc_serv_button = root.findViewById(R.id.adc_serv_button);


//LISTVIEW============================================================================================================

        listaListView = root.findViewById(R.id.all_serv_listview);
        lista = new ArrayList<ServicosRealizados>();
        listaArrayAdapter = new ArrayAdapter<ServicosRealizados>(getContext(),
                android.R.layout.simple_list_item_1,
                lista);
        listaListView.setAdapter(listaArrayAdapter);
//excluir registros ao pressionar no item aparece um dialogo======================================================================
        listaListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Deseja cancelar o registro?");

                builder.setPositiveButton("OK",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        int id_serv_realizado = listaArrayAdapter.getItem(position).getId_servicoRealizado();
                        bancoDados.apagarServicoRealizado(id_serv_realizado);
                        lista.remove(position);
                        listaArrayAdapter.notifyDataSetChanged();
                    }
                });

                builder.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                builder.show();

                return true;
            }
        });
//excluir registros ao pressionar no item aparece um dialogo======================================================================

        bancoDados.carregarServicosRealizados(lista,id_veiculo,id_cat_servico);
        listaArrayAdapter.notifyDataSetChanged();


//LISTVIEW============================================================================================================

//FUNÇÃO DO BOTÃO ADICIONAR SERVICOS==================================================================================
        adc_serv_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment fragment;

                if (id_cat_servico == 1){
                    fragment = new CombustivelFragment();
                    //fragment = new SeguroFragment();
                    //==============================================================================================
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico",1);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //ft.addToBackStack(null);
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();

                }else if (id_cat_servico == 2){
                    fragment = new ServicosFragment();
                    //fragment = new SeguroFragment();
                    //==============================================================================================
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico",2);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //ft.addToBackStack(null);
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();

                }else if (id_cat_servico == 3){
                    fragment = new DespesasFragment();
                    //fragment = new SeguroFragment();
                    //==============================================================================================
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico",3);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //ft.addToBackStack(null);
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();

                }else if (id_cat_servico == 4){
                    fragment = new OleoFragment();
                    //fragment = new SeguroFragment();
                    //==============================================================================================
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico",4);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //ft.addToBackStack(null);
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();

                }else if (id_cat_servico == 5){
                    fragment = new SeguroFragment();
                    //fragment = new SeguroFragment();
                    //==============================================================================================
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico",5);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //ft.addToBackStack(null);
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();

                }
            }
        });
///FUNÇÃO DO BOTÃO ADICIONAR SERVICOS==================================================================================

//altera o textView ==================================================================================================
        if (id_cat_servico == 1){
            all_serv_textView.setText("Histórico de Abastecimento");
        }else if (id_cat_servico == 2){
            all_serv_textView.setText("Histórico de Serviços");
        }else if (id_cat_servico == 3){
            all_serv_textView.setText("Histórico de Despesas");
        }else if (id_cat_servico == 4){
            all_serv_textView.setText("Histórico de Troca de Óleo");
        }else if (id_cat_servico == 5){
            all_serv_textView.setText("Histórico de Seguro");
        }
//altera o textView ==================================================================================================


        //Toast.makeText(getContext(),id_usuario+" - "+id_veiculo,Toast.LENGTH_LONG).show();

        return root;
    }


}