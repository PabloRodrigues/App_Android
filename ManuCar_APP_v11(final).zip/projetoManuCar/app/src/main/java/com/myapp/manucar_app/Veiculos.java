package com.myapp.manucar_app;

public class Veiculos {

    int id_veiculos;
    String placa_veiculo;
    String modelo;
    String ano_fab;
    int id_fabricante;
    int id_usuarios;

    public Veiculos() {
    }

    public Veiculos(int id_veiculos, String placa_veiculo, String modelo, String ano_fab, int id_fabricante, int id_usuarios) {
        this.id_veiculos = id_veiculos;
        this.placa_veiculo = placa_veiculo;
        this.modelo = modelo;
        this.ano_fab = ano_fab;
        this.id_fabricante = id_fabricante;
        this.id_usuarios = id_usuarios;
    }

    public Veiculos(String placa_veiculo, String modelo, String ano_fab, int id_usuarios, int id_fabricante){
        //construtor vazio
        this.placa_veiculo = placa_veiculo;
        this.modelo        = modelo;
        this.ano_fab       = ano_fab;
        this.id_usuarios   = id_usuarios;
        this.id_fabricante = id_fabricante;
    }

    public Veiculos(String placa_veiculo, String modelo, String ano_fab) {

        this.placa_veiculo = placa_veiculo;
        this.modelo = modelo;
        this.ano_fab = ano_fab;
        this.id_fabricante = id_fabricante;
    }

    public Veiculos(int id_veiculos, String placa_veiculo, String modelo, String ano_fab) {
        this.id_veiculos = id_veiculos;
        this.placa_veiculo = placa_veiculo;
        this.modelo = modelo;
        this.ano_fab = ano_fab;
    }

    public Veiculos(String placa_veiculo, String modelo) {
        this.placa_veiculo = placa_veiculo;
        this.modelo = modelo;
    }


    @Override
    public String toString() {
        return placa_veiculo + " - " + modelo;
    }


    public int getId_veiculos() {
        return id_veiculos;
    }

    public void setId_veiculos(int id_veiculos) {
        this.id_veiculos = id_veiculos;
    }

    public String getPlaca_veiculo() {
        return placa_veiculo;
    }

    public void setPlaca_veiculo(String placa_veiculo) {
        this.placa_veiculo = placa_veiculo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAno_fab() {
        return ano_fab;
    }

    public void setAno_fab(String ano_fab) {
        this.ano_fab = ano_fab;
    }

    public int getId_fabricante() {
        return id_fabricante;
    }

    public void setId_fabricante(int id_fabricante) {
        this.id_fabricante = id_fabricante;
    }

    public int getId_usuarios() {
        return id_usuarios;
    }

    public void setId_usuarios(int id_usuarios) {
        this.id_usuarios = id_usuarios;
    }

}
