package com.myapp.manucar_app.ui.graficos;

import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;
import com.myapp.manucar_app.BancoDados;
import com.myapp.manucar_app.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class GraficosFragment extends Fragment {

    SQLiteDatabase sqLiteDatabase;
    private BancoDados bancoDados;

    int id_usuario;
    int id_veiculo;

    String dataMinString = null;
    String dataMaxString = null;
    int dataMinINT = 11111111;
    int dataMaxINT = 99999999;

    EditText dt_min_edt;
    EditText dt_max_edt;
    Button datas_button;

    PieChart pieChart;  // Grafico 0 = distribuição de combustivel
    PieChart pieChart1; // Grafico 1 = distribuição de serviços
    PieChart pieChart2; // Grafico 2 = distribuição de despesas
    PieChart pieChart3; // Grafico 3


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        final View root = inflater.inflate(R.layout.fragment_graficos, container, false);

        bancoDados = new BancoDados(getContext());
        sqLiteDatabase = bancoDados.getWritableDatabase();

//recupera os dados passados por argumentos da mainActivity===========================================================
        Bundle bundle = getArguments();
        if (bundle != null) {
            id_usuario = bundle.getInt("id_usuario");
            id_veiculo = bundle.getInt("id_veiculo");
        }
//recupera os dados passados por argumentos da mainActivity===========================================================

//Grafico 0 =========================================================================================================================================
        pieChart =(PieChart) root.findViewById(R.id.piechart);

        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        //pieChart.setExtraOffsets(5,10,5,5);
        pieChart.setDragDecelerationFrictionCoef(0.95f);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setTransparentCircleRadius(61f);

        ArrayList<PieEntry> yValues = bancoDados.getPieEntries(id_veiculo,1,dataMinINT,dataMaxINT);//somente combustivel

        //configura as fatias=============================================
        PieDataSet dataSet = new PieDataSet(yValues,"");//entrada de dados
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        //configura as fatias=============================================

        PieData data = new PieData(dataSet);//aquiii
        data.setValueTextSize(20f);
        data.setValueTextColor(Color.BLACK);

        pieChart.animateY(1000, Easing.EasingOption.EaseInCubic);
        pieChart.setData(data);
        pieChart.notifyDataSetChanged();
        pieChart.invalidate();
//Grafico 0 =========================================================================================================================================
//Grafico 1 =========================================================================================================================================
        pieChart1 =(PieChart) root.findViewById(R.id.piechart1);

        pieChart1.setUsePercentValues(true);
        pieChart1.getDescription().setEnabled(false);
        //pieChart.setExtraOffsets(5,10,5,5);
        pieChart1.setDragDecelerationFrictionCoef(0.95f);
        pieChart1.setDrawHoleEnabled(true);
        pieChart1.setHoleColor(Color.WHITE);
        pieChart1.setTransparentCircleRadius(61f);

        ArrayList<PieEntry> yValues1 = bancoDados.getPieEntries(id_veiculo,2,dataMinINT,dataMaxINT);//somente combustivel
        //configura as fatias=============================================
        PieDataSet dataSet1 = new PieDataSet(yValues1,"");
        dataSet1.setSliceSpace(3f);
        dataSet1.setSelectionShift(5f);
        dataSet1.setColors(ColorTemplate.COLORFUL_COLORS);
        //configura as fatias=============================================

        PieData data1 = new PieData(dataSet1);
        data1.setValueTextSize(20f);
        data1.setValueTextColor(Color.BLACK);

        pieChart1.animateY(1000, Easing.EasingOption.EaseInCubic);
        pieChart1.setData(data1);
//Grafico 1 =========================================================================================================================================
//Grafico 2 =========================================================================================================================================
        pieChart2 =(PieChart) root.findViewById(R.id.piechart2);

        pieChart2.setUsePercentValues(true);
        pieChart2.getDescription().setEnabled(false);
        //pieChart.setExtraOffsets(5,10,5,5);
        pieChart2.setDragDecelerationFrictionCoef(0.95f);
        pieChart2.setDrawHoleEnabled(true);
        pieChart2.setHoleColor(Color.WHITE);
        pieChart2.setTransparentCircleRadius(61f);

        ArrayList<PieEntry> yValues2 = bancoDados.getPieEntries(id_veiculo,3,dataMinINT,dataMaxINT);//somente combustivel
        //configura as fatias=============================================
        PieDataSet dataSet2 = new PieDataSet(yValues2,"");
        dataSet2.setSliceSpace(3f);
        dataSet2.setSelectionShift(5f);
        dataSet2.setColors(ColorTemplate.COLORFUL_COLORS);
        //configura as fatias=============================================

        PieData data2 = new PieData(dataSet2);
        data2.setValueTextSize(20f);
        data2.setValueTextColor(Color.BLACK);

        pieChart2.animateY(1000, Easing.EasingOption.EaseInCubic);
        pieChart2.setData(data2);
//Grafico 2 =========================================================================================================================================
//Grafico 3 =========================================================================================================================================
        pieChart3 =(PieChart) root.findViewById(R.id.piechart3);

        pieChart3.setUsePercentValues(true);
        pieChart3.getDescription().setEnabled(false);
        //pieChart.setExtraOffsets(5,10,5,5);
        pieChart3.setDragDecelerationFrictionCoef(0.95f);
        pieChart3.setDrawHoleEnabled(true);
        pieChart3.setHoleColor(Color.WHITE);
        pieChart3.setTransparentCircleRadius(61f);

        ArrayList<PieEntry> yValues3 = bancoDados.getPieEntries2(id_veiculo,dataMinINT,dataMaxINT);//somente combustivel
        //configura as fatias=============================================
        PieDataSet dataSet3 = new PieDataSet(yValues3,"");
        dataSet3.setSliceSpace(3f);
        dataSet3.setSelectionShift(5f);
        dataSet3.setColors(ColorTemplate.COLORFUL_COLORS);
        //configura as fatias=============================================

        PieData data3 = new PieData(dataSet3);
        data3.setValueTextSize(20f);
        data3.setValueTextColor(Color.BLACK);

        pieChart3.animateY(1000, Easing.EasingOption.EaseInCubic);
        pieChart3.setData(data3);
//Grafico 3 =========================================================================================================================================

        //trabalahando com o filtro das datas======================================================================================================================
        dt_min_edt = root.findViewById(R.id.data_min_edt);
        dt_max_edt = root.findViewById(R.id.data_max_edt);
        datas_button = root.findViewById(R.id.datas_button);

        //criando mascara de data==============================================
        SimpleMaskFormatter smf = new SimpleMaskFormatter("NN/NN/NNNN");
        MaskTextWatcher mtw = new MaskTextWatcher(dt_min_edt,smf);
        MaskTextWatcher mtw1 = new MaskTextWatcher(dt_max_edt,smf);
        dt_min_edt.addTextChangedListener(mtw);
        dt_max_edt.addTextChangedListener(mtw1);
        //criando mascara de data==============================================

        datas_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dataMinString = dt_min_edt.getText().toString();//recebe a data em String no fomato "DD/MM/YYYY"
                if (dataMinString.isEmpty()) {
                    dataMinINT = 11111111;

                }else{
                    String dataMinTemp = dataMinString.substring(6, 10)+""+ dataMinString.substring(3, 5)+""+ dataMinString.substring(0,2);//Transforma a data em YYYYmmDD (String)
                    dataMinINT = Integer.parseInt(dataMinTemp);// transformo data YYYYmmDD em int
                }

                dataMaxString = dt_max_edt.getText().toString();//recebe a data em String no fomato "DD/MM/YYYY"
                if (dataMaxString.isEmpty()) {
                    dataMaxINT = 99999999;
                }else{
                    String dataMaxTemp = dataMaxString.substring(6, 10)+""+ dataMaxString.substring(3, 5)+""+ dataMaxString.substring(0,2);//Transforma a data em YYYYmmDD (String)
                    dataMaxINT = Integer.parseInt(dataMaxTemp);// transformo data YYYYmmDD em int
                }
                dt_max_edt.setText("");
                dt_min_edt.setText("");

                if (dataMinINT<dataMaxINT) {
                    //RECONFIGURA O GRAFICO 0==============================================================================================================
                    pieChart = (PieChart) root.findViewById(R.id.piechart);
                    pieChart.setUsePercentValues(true);
                    pieChart.getDescription().setEnabled(false);
                    pieChart.setExtraOffsets(5, 10, 5, 5);
                    pieChart.setDragDecelerationFrictionCoef(0.95f);
                    pieChart.setDrawHoleEnabled(true);
                    pieChart.setHoleColor(Color.WHITE);
                    pieChart.setTransparentCircleRadius(61f);
                    ArrayList<PieEntry> yValues = bancoDados.getPieEntries(id_veiculo, 1, dataMinINT, dataMaxINT);//somente combustivel
                    PieDataSet dataSet = new PieDataSet(yValues, "");//entrada de dados
                    dataSet.setSliceSpace(3f);
                    dataSet.setSelectionShift(5f);
                    dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
                    PieData data = new PieData(dataSet);//aquiii
                    data.setValueTextSize(20f);
                    data.setValueTextColor(Color.BLACK);
                    pieChart.animateY(1000, Easing.EasingOption.EaseInCubic);
                    pieChart.setData(data);
                    pieChart.notifyDataSetChanged();
                    pieChart.invalidate();
                    //RECONFIGURA O GRAFICO 0==============================================================================================================
                    //RECONFIGURA O GRAFICO 1 =========================================================================================================================================
                    pieChart1 = (PieChart) root.findViewById(R.id.piechart1);
                    pieChart1.setUsePercentValues(true);
                    pieChart1.getDescription().setEnabled(false);
                    pieChart1.setExtraOffsets(5, 10, 5, 5);
                    pieChart1.setDragDecelerationFrictionCoef(0.95f);
                    pieChart1.setDrawHoleEnabled(true);
                    pieChart1.setHoleColor(Color.WHITE);
                    pieChart1.setTransparentCircleRadius(61f);
                    ArrayList<PieEntry> yValues1 = bancoDados.getPieEntries(id_veiculo, 2, dataMinINT, dataMaxINT);//somente combustivel
                    PieDataSet dataSet1 = new PieDataSet(yValues1, "");
                    dataSet1.setSliceSpace(3f);
                    dataSet1.setSelectionShift(5f);
                    dataSet1.setColors(ColorTemplate.COLORFUL_COLORS);
                    PieData data1 = new PieData(dataSet1);
                    data1.setValueTextSize(20f);
                    data1.setValueTextColor(Color.BLACK);
                    pieChart1.animateY(1000, Easing.EasingOption.EaseInCubic);
                    pieChart1.setData(data1);
                    pieChart1.notifyDataSetChanged();
                    pieChart1.invalidate();
                    //RECONFIGURA O GRAFICO 1 =========================================================================================================================================
                    //RECONFIGURA O GRAFICO 2 =========================================================================================================================================
                    pieChart2 = (PieChart) root.findViewById(R.id.piechart2);
                    pieChart2.setUsePercentValues(true);
                    pieChart2.getDescription().setEnabled(false);
                    pieChart2.setExtraOffsets(5, 10, 5, 5);
                    pieChart2.setDragDecelerationFrictionCoef(0.95f);
                    pieChart2.setDrawHoleEnabled(true);
                    pieChart2.setHoleColor(Color.WHITE);
                    pieChart2.setTransparentCircleRadius(61f);
                    ArrayList<PieEntry> yValues2 = bancoDados.getPieEntries(id_veiculo, 3, dataMinINT, dataMaxINT);//somente combustivel
                    PieDataSet dataSet2 = new PieDataSet(yValues2, "");
                    dataSet2.setSliceSpace(3f);
                    dataSet2.setSelectionShift(5f);
                    dataSet2.setColors(ColorTemplate.COLORFUL_COLORS);
                    PieData data2 = new PieData(dataSet2);
                    data2.setValueTextSize(20f);
                    data2.setValueTextColor(Color.BLACK);
                    pieChart2.animateY(1000, Easing.EasingOption.EaseInCubic);
                    pieChart2.setData(data2);
                    pieChart2.notifyDataSetChanged();
                    pieChart2.invalidate();
                    //RECONFIGURA O GRAFICO 2 =========================================================================================================================================
                    //RECONFIGURA O GRAFICO 3 =========================================================================================================================================
                    pieChart3 = (PieChart) root.findViewById(R.id.piechart3);
                    pieChart3.setUsePercentValues(true);
                    pieChart3.getDescription().setEnabled(false);
                    pieChart3.setExtraOffsets(5, 10, 5, 5);
                    pieChart3.setDragDecelerationFrictionCoef(0.95f);
                    pieChart3.setDrawHoleEnabled(true);
                    pieChart3.setHoleColor(Color.WHITE);
                    pieChart3.setTransparentCircleRadius(61f);
                    ArrayList<PieEntry> yValues3 = bancoDados.getPieEntries2(id_veiculo, dataMinINT, dataMaxINT);//somente combustivel
                    PieDataSet dataSet3 = new PieDataSet(yValues3, "");
                    dataSet3.setSliceSpace(3f);
                    dataSet3.setSelectionShift(5f);
                    dataSet3.setColors(ColorTemplate.COLORFUL_COLORS);
                    PieData data3 = new PieData(dataSet3);
                    data3.setValueTextSize(20f);
                    data3.setValueTextColor(Color.BLACK);
                    pieChart3.animateY(1000, Easing.EasingOption.EaseInCubic);
                    pieChart3.setData(data3);
                    pieChart3.notifyDataSetChanged();
                    pieChart3.invalidate();
                    //RECONFIGURA O GRAFICO 3 =========================================================================================================================================
                }else{
                    dt_max_edt.setError("Data máxima menor que a data mínima");

                    dataMaxINT=99999999;
                    dataMinINT=11111111;
                }

            }

        });

//trabalahando com o filtro das datas======================================================================================================================



        return root;
    }


}