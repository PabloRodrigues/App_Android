package com.myapp.manucar_app;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;

import java.util.ArrayList;

public class TelaRegistroVeiculoActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText CAD_PLACA_editText;
    private EditText CAD_FABRICANTE_editText;
    private EditText CAD_MODELO_editText;
    private EditText CAD_ANO_editText;

    private ArrayList<Fabricante> lista;
    private ArrayAdapter<Fabricante> adapter;

    public Button btn_cadastrarVeiculo;

    String loginIT;
    String senhaIT;

    BancoDados bancoDados = new BancoDados(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_registro_veiculo);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        bancoDados = new BancoDados(this);


        CAD_PLACA_editText      = findViewById(R.id.CAD_PLACA_editText3);
        CAD_FABRICANTE_editText = findViewById(R.id.CAD_FABRICANTE_editText);
        CAD_MODELO_editText     = findViewById(R.id.CAD_MODELO_editText2);
        CAD_ANO_editText        = findViewById(R.id.CAD_ANO_editText);

        btn_cadastrarVeiculo    = findViewById(R.id.CAD_CADASTRAR_VEICULO_button);
        btn_cadastrarVeiculo.setOnClickListener(this);

        //criando mascara de data==============================================
        SimpleMaskFormatter smf = new SimpleMaskFormatter("NNNN");
        MaskTextWatcher mtw = new MaskTextWatcher(CAD_ANO_editText,smf);
        CAD_ANO_editText.addTextChangedListener(mtw);

        SimpleMaskFormatter smf1 = new SimpleMaskFormatter("AAAAAAA");
        MaskTextWatcher mtw1 = new MaskTextWatcher(CAD_PLACA_editText,smf1);
        CAD_PLACA_editText.addTextChangedListener(mtw1);

        //criando mascara de data==============================================

        //cria a lista
        ListView listaListView = new ListView(this);
        lista = new ArrayList<Fabricante>();
        adapter = new ArrayAdapter<Fabricante>(this,
                android.R.layout.simple_expandable_list_item_1,
                lista);
        listaListView.setAdapter(adapter);

        //cria o dialogo
        AlertDialog.Builder builder = new AlertDialog.Builder(TelaRegistroVeiculoActivity.this);
        builder.setCancelable(true);
        builder.setView(listaListView);
        final AlertDialog dialog =builder.create();

        //função do botão fabricante para abrir as opções
        CAD_FABRICANTE_editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bancoDados.carregarFabricantes(lista);
                adapter.notifyDataSetChanged();
                dialog.show();
            }
        });

        //função de click nos item da lista para salvar no editText
        listaListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               CAD_FABRICANTE_editText.setText(adapter.getItem(position).toString());
               dialog.dismiss();
            }
        });

//RECUPERA  o id do usuario INTENT MENU ATRAVES DO BUNDLES.------------------------------------------------------------------------
        Intent intentMenu = getIntent();
        Bundle extrasMenu  = intentMenu.getExtras();
        if (extrasMenu != null) {
            loginIT = extrasMenu.getString("loginIT");
            senhaIT = extrasMenu.getString("senhaIT");
        }
//RECUPERA  o id do usuario INTENT MENU ATRAVES DO BUNDLES.------------------------------------------------------------------------

    }


    @Override
    public void onClick(View v) {
        switch(v.getId()) {

            case R.id.CAD_CADASTRAR_VEICULO_button:

//RECUPERA  o id do usuario INTENT MENU ATRAVES DO BUNDLES.------------------------------------------------------------------------
                Usuario usuario1 = bancoDados.selecionarUsuario(loginIT, senhaIT);
                int id_usuario = usuario1.getId_usuario();
//RECUPERA  o id do usuario INTENT MENU ATRAVES DO BUNDLES.------------------------------------------------------------------------

                String placa        = CAD_PLACA_editText.getText().toString();
                String fabr_temp    = CAD_FABRICANTE_editText.getText().toString();
                String modelo       = CAD_MODELO_editText.getText().toString();
                String ano          = CAD_ANO_editText.getText().toString();

                if(placa.isEmpty() || placa.length()<7){
                    CAD_PLACA_editText.setError("Este campo é obrigatorio (7 digitos)");
                }else if(fabr_temp.isEmpty()){
                    CAD_FABRICANTE_editText.setError("Este campo é obrigatorio");
                }else if(modelo.isEmpty()){
                    CAD_MODELO_editText.setError("Este campo é obrigatorio");
                }else if(ano.isEmpty() || ano.length()< 4 ){
                    CAD_ANO_editText.setError("Este campo é obrigatorio (4 digitos)");
                }else {

                    Fabricante fabricante1 = bancoDados.selecionarFabricante(fabr_temp);
                    int id_fabr = fabricante1.getId_fabricante();

                    bancoDados.addVeiculo(new Veiculos(placa,modelo,ano,id_usuario,id_fabr));
                    Toast.makeText(TelaRegistroVeiculoActivity.this,"Veículo criado com sucesso!",Toast.LENGTH_SHORT).show();

                    Intent intentRVeiculo = new Intent(TelaRegistroVeiculoActivity.this, TelaMenuActivity.class);
                    Bundle extrasRVeiculo = new Bundle();
                    extrasRVeiculo.putString("loginIT1",loginIT);
                    extrasRVeiculo.putString("senhaIT1",senhaIT);

                    intentRVeiculo.putExtras(extrasRVeiculo);
                    startActivity(intentRVeiculo);

                    finish();
                }


                break;

        };

    }
}
