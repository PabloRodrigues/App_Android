package com.myapp.manucar_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;

import androidx.annotation.Nullable;

import static android.icu.text.MessagePattern.ArgType.SELECT;

public class BancoDados extends SQLiteOpenHelper {


    //cria versão do banco e o nome do banco
    private static final int VERSAO_BANCO = 29;
    private static final String BANCO_MANUCAR = "bd_manucar";

    //TABELA USUARIO-------------------------------------------------------------------------------------
    private static final String TABELA_USUARIO = "tb_usuario";

    private static final String COLUNA_ID = "id_usuarios";
    private static final String COLUNA_NOME = "nome_usuario";
    private static final String COLUNA_CPF = "cpf_usuario";
    private static final String COLUNA_EMAIL = "email_usuario";
    private static final String COLUNA_LOGIN = "login_usuario";
    private static final String COLUNA_SENHA = "senha_usuario";
    //TABELA VEICULOS-------------------------------------------------------------------------------------
    private static final String TABELA_VEICULO = "tb_veiculo";

    private static final String COLUNA_ID_VEICULOS = "id_veiculos";
    private static final String COLUNA_PLACA = "placa_veiculo";
    private static final String COLUNA_ANO = "ano_fab";
    private static final String COLUNA_MODELO = "modelo";
    //private static final String COLUNA_EMAIL = "email_usuario"; ID_USUARIO
    //private static final String COLUNA_LOGIN = "login_usuario"; ID_FABRICANTES
    //TABELA FABRICANTES-----------------------------------------------------------------------------------
    private static final String TABELA_FABRICANTES = "tb_fabricantes";

    private static final String COLUNA_ID_FABRICANTES = "id_fabricantes";
    private static final String COLUNA_NOME_FAB = "fab_nome";
    //TABELA CATEGORIA SERVICOS----------------------------------------------------------------------------
    private static final String TABELA_CAT_SERV = "tb_categoria_servicos";

    private static final String COLUNA_ID_CAT_SERVICOS = "id_categoria_servicos";
    private static final String COLUNA_NOME_CAT_SERV = "nome_cat_servicos";
    //TABELA CATEGORIA SERVICOS----------------------------------------------------------------------------
    private static final String TABELA_SERV = "tb_servicos";

    private static final String COLUNA_ID_SERVICOS = "id_servicos";
    private static final String COLUNA_NOME_SERV = "nome_servicos";

    //TABELA SERVICOS REALIZADOS----------------------------------------------------------------------------
    private static final String TABELA_SERV_REALIZADOS = "tb_servicos_realizados";

    private static final String COLUNA_ID_SERVICOS_REALIZADOS = "id_servicos_realizados";
    private static final String COLUNA_DATA_SERV = "data_serv";
    private static final String COLUNA_VALOR_UNIT = "valor_unit_serv";
    private static final String COLUNA_VALOR_TOTAL = "valor_total_serv";
    private static final String COLUNA_QTD_SERV = "qtd_serv";
    private static final String COLUNA_ODOMETRO_SERV = "odometro_serv";
    private static final String COLUNA_RAZAOSOCIAL_SERV = "razao_social_serv";
    private static final String COLUNA_VALIDADE_SEGURO = "validade_seguro";

    ///////////////////////////////////////////////////////////////////////////


    public BancoDados(@Nullable Context context) {
        super(context, BANCO_MANUCAR, null, VERSAO_BANCO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //CRIAÇÃO E EXECUÇÃO DAS QUERYS DAS TABELAS
        String QUERY_COLUNA = "CREATE TABLE " + TABELA_USUARIO + "("
                + COLUNA_ID + " INTEGER PRIMARY KEY ASC AUTOINCREMENT, "
                + COLUNA_NOME + " TEXT NOT NULL, "
                + COLUNA_CPF + " TEXT , "
                + COLUNA_EMAIL + " TEXT NOT NULL, "
                + COLUNA_LOGIN + " TEXT NOT NULL, "
                + COLUNA_SENHA + " TEXT NOT NULL)";

        db.execSQL(QUERY_COLUNA);

        String QUERY_COLUNA_VEICULOS = "CREATE TABLE " + TABELA_VEICULO + "("
                + COLUNA_ID_VEICULOS + " INTEGER PRIMARY KEY ASC AUTOINCREMENT, "
                + COLUNA_PLACA + " TEXT NOT NULL, "
                + COLUNA_ANO + " INTEGER NOT NULL, "
                + COLUNA_MODELO + " TEXT NOT NULL, "
                + COLUNA_ID + " INTEGER NOT NULL REFERENCES " + TABELA_USUARIO + "(" + COLUNA_ID + "), "
                + COLUNA_ID_FABRICANTES + " INTEGER NOT NULL REFERENCES " + TABELA_FABRICANTES + "(" + COLUNA_ID_FABRICANTES + "))";

        db.execSQL(QUERY_COLUNA_VEICULOS);

        //db.execSQL("INSERT INTO " + TABELA_VEICULO + " values (null, 'kyz0800', 2018,'palio',1,1)");

        String QUERY_COLUNA_FABRICANTES = "CREATE TABLE " + TABELA_FABRICANTES + "("
                + COLUNA_ID_FABRICANTES + " INTEGER PRIMARY KEY ASC AUTOINCREMENT, "
                + COLUNA_NOME_FAB + " TEXT NOT NULL)";

        db.execSQL(QUERY_COLUNA_FABRICANTES);

        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (1, 'FIAT')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (2, 'CHEVROLET')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (3, 'FORD')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (4, 'HONDA')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (5, 'HYUNDAI')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (6, 'PEUGEOT')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (7, 'RENAULT')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (8, 'TOYOTA')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (9, 'VOLKSWAGEN')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (10,'NISSAN')");
        db.execSQL("INSERT INTO " + TABELA_FABRICANTES + " values (11,'OUTROS')");

        String QUERY_COLUNA_CAT_SERV = "CREATE TABLE " + TABELA_CAT_SERV + "("
                + COLUNA_ID_CAT_SERVICOS + " INTEGER PRIMARY KEY ASC NOT NULL, "
                + COLUNA_NOME_CAT_SERV + " TEXT NOT NULL)";

        db.execSQL(QUERY_COLUNA_CAT_SERV);

        db.execSQL("INSERT INTO " + TABELA_CAT_SERV + " values (1, 'Abastecimento')");
        db.execSQL("INSERT INTO " + TABELA_CAT_SERV + " values (2, 'Servicos')");
        db.execSQL("INSERT INTO " + TABELA_CAT_SERV + " values (3, 'Despesas')");
        db.execSQL("INSERT INTO " + TABELA_CAT_SERV + " values (4, 'Óleo')");
        db.execSQL("INSERT INTO " + TABELA_CAT_SERV + " values (5, 'Seguro')");

        String QUERY_COLUNA_SERVICOS = "CREATE TABLE " + TABELA_SERV + "("
                + COLUNA_ID_SERVICOS + " INTEGER PRIMARY KEY ASC NOT NULL, "
                + COLUNA_NOME_SERV + " TEXT NOT NULL, "
                + COLUNA_ID_CAT_SERVICOS + " INTEGER NOT NULL REFERENCES " + TABELA_CAT_SERV + "(" + COLUNA_ID_CAT_SERVICOS + ")) ";

        db.execSQL(QUERY_COLUNA_SERVICOS);

        db.execSQL("INSERT INTO " + TABELA_SERV + " values (1, 'Gasolina',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (2, 'Etanol',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (3, 'Diesel',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (4, 'Gas. Aditiv.',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (5, 'GNV',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (6, 'Gas. Alta Oct.',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (7, 'Etanol Aditiv.',1)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (8, 'Ar-Condicionado',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (9, 'Bateria',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (10, 'Buzinas',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (11, 'Correias',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (12, 'Direção Hidráulica',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (13, 'Filtro de Ar',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (14, 'Filtro de Ar da Cabine',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (15, 'Filtro de Combustível',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (16, 'Filtro de Óleo',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (17, 'Fluído da Embreagem',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (18, 'Fluído da Transmissão',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (19, 'Fluído de Freio',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (20, 'Funilaria',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (21, 'Inspeção Técnica/ControlAR',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (22, 'Limpadores de Para-brisa',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (23, 'Luzes',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (24, 'Mão de Obra',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (25, 'Outro',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (26, 'Pastilha de Freio',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (27, 'Pneus',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (28, 'Pneus - Alinhamento/Balanc.',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (29, 'Pneus - Pressão',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (30, 'Pneus - Rodízio',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (31, 'Radiador',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (32, 'Reparo no Motor',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (33, 'Revisão',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (34, 'Sistema de Aquecimento',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (35, 'Sistema de Embreagem',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (36, 'Sistema de Exaustão',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (37, 'Sistema de Refrigeramento',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (38, 'Suspensão/Amortecedores',	2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (39, 'Troca de Freio',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (40, 'Velas de Ignição',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (41, 'Vidros/Espelhos',2)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (42, 'Acidente',	3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (43, 'Estacionamento',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (44, 'Financiamento',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (45, 'Impostos (IPVA/DPVAT)',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (46, 'Lava-rápido',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (47, 'Licenciamento',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (48, 'Multa',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (49, 'Outro',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (50, 'Pagamentos',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (51, 'Pedágio',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (52, 'Reembolso',3)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (53, 'Troca de Óleo',4)");
        db.execSQL("INSERT INTO " + TABELA_SERV + " values (54, 'Seguro',5)");

        String QUERY_COLUNA_SERV_REALIZADOS = "CREATE TABLE " + TABELA_SERV_REALIZADOS + "("
                + COLUNA_ID_SERVICOS_REALIZADOS + " INTEGER PRIMARY KEY ASC AUTOINCREMENT, "
                + COLUNA_DATA_SERV + " INTEGER  NOT NULL, "
                + COLUNA_VALOR_UNIT + " REAL NOT NULL, "
                + COLUNA_VALOR_TOTAL + " REAL NOT NULL, "
                + COLUNA_QTD_SERV + " REAL NOT NULL, "
                + COLUNA_ODOMETRO_SERV + " INTEGER, "
                + COLUNA_RAZAOSOCIAL_SERV + " TEXT, "
                + COLUNA_VALIDADE_SEGURO + " INTEGER , "
                + COLUNA_ID_SERVICOS + " INTEGER NOT NULL REFERENCES " + TABELA_SERV + "(" + COLUNA_ID_SERVICOS + "), "
                + COLUNA_ID_VEICULOS + " INTEGER NOT NULL REFERENCES " + TABELA_VEICULO + "(" + COLUNA_ID_VEICULOS + "))";

        db.execSQL(QUERY_COLUNA_SERV_REALIZADOS);


        //db.execSQL("INSERT INTO tb_servicos_realizados values (null, '20190301', 52.7, 2, 120000, 'Shell', null, 1, 1)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
/*
        String QUERY_COLUNA_SERV_REALIZADOS = "CREATE TABLE " + TABELA_SERV_REALIZADOS + "("
                + COLUNA_ID_SERVICOS_REALIZADOS + " INTEGER PRIMARY KEY ASC AUTOINCREMENT, "
                + COLUNA_DATA_SERV + " INTEGER  NOT NULL, "
                + COLUNA_VALOR_UNIT + " REAL NOT NULL, "
                + COLUNA_VALOR_TOTAL + " REAL NOT NULL, "
                + COLUNA_QTD_SERV + " REAL NOT NULL, "
                + COLUNA_ODOMETRO_SERV + " INTEGER, "
                + COLUNA_RAZAOSOCIAL_SERV + " TEXT, "
                + COLUNA_VALIDADE_SEGURO + " INTEGER , "
                + COLUNA_ID_SERVICOS + " INTEGER NOT NULL REFERENCES " + TABELA_SERV + "(" + COLUNA_ID_SERVICOS + "), "
                + COLUNA_ID_VEICULOS + " INTEGER NOT NULL REFERENCES " + TABELA_VEICULO + "(" + COLUNA_ID_VEICULOS + "))";

        db.execSQL(QUERY_COLUNA_SERV_REALIZADOS);

        /*
        String sql = "DROP TABLE IF EXISTS tb_servicos_realizados";
        db.execSQL(sql);


         */
    }

    public void addServicoRealizado(ServicosRealizados servicosRealizados) {
        //FUNÇÃO PARA ADCIONAR USUARIO "CADASTRO"

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUNA_DATA_SERV, servicosRealizados.dataServ);
        values.put(COLUNA_VALOR_UNIT, servicosRealizados.valorUnitario);
        values.put(COLUNA_VALOR_TOTAL,servicosRealizados.valorTotal);
        values.put(COLUNA_QTD_SERV, servicosRealizados.qtdServ);
        values.put(COLUNA_ODOMETRO_SERV, servicosRealizados.odometroServ);
        values.put(COLUNA_RAZAOSOCIAL_SERV, servicosRealizados.razaoSocialServ);
        values.put(COLUNA_VALIDADE_SEGURO,servicosRealizados.dataValidadeSeguro);
        values.put(COLUNA_ID_SERVICOS,servicosRealizados.id_servico);
        values.put(COLUNA_ID_VEICULOS,servicosRealizados.id_veiculo);

        db.insert(TABELA_SERV_REALIZADOS, null, values);
        db.close();
    }

    void addUsuario(Usuario usuario) {
        //FUNÇÃO PARA ADCIONAR USUARIO "CADASTRO"

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUNA_NOME, usuario.nome_usuario);
        values.put(COLUNA_CPF, usuario.cpf_usuario);
        values.put(COLUNA_EMAIL, usuario.email_usuario);
        values.put(COLUNA_LOGIN, usuario.login_usuario);
        values.put(COLUNA_SENHA, usuario.senha_usuario);

        db.insert(TABELA_USUARIO, null, values);
        db.close();
    }

    void addVeiculo(Veiculos veiculos) {
        //FUNÇÃO PARA ADCIONAR VEICULO "CADASTRO"

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUNA_PLACA, veiculos.getPlaca_veiculo());
        values.put(COLUNA_MODELO, veiculos.getModelo());
        values.put(COLUNA_ANO, veiculos.getAno_fab());
        values.put(COLUNA_ID, veiculos.getId_usuarios());
        values.put(COLUNA_ID_FABRICANTES,veiculos.getId_fabricante());


        db.insert(TABELA_VEICULO, null, values);
        db.close();
    }

//----------------------------------------------------------------------------------------------------------------
    public void carregarServicosRealizados(ArrayList<ServicosRealizados> lista, int id_veiculo, int id_cat_serv) {
        lista.clear();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT id_servicos_realizados, nome_servicos, data_serv, valor_unit_serv, valor_total_serv ,qtd_serv  FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                "JOIN tb_categoria_servicos c "  + "ON c.id_categoria_servicos = v.id_categoria_servicos "+
                " WHERE u.id_veiculos = ? AND v.id_categoria_servicos = ?"+
                " ORDER BY data_serv";

        String coluna[] = new String[6];
                            coluna[0] = COLUNA_ID_SERVICOS_REALIZADOS;coluna[1] = COLUNA_NOME_SERV; coluna[2] = COLUNA_DATA_SERV;
                            coluna[3] = COLUNA_VALOR_UNIT; coluna[4] = COLUNA_VALOR_TOTAL; coluna[5] = COLUNA_QTD_SERV;

        Cursor cursor = getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(id_veiculo),String.valueOf(id_cat_serv)});
        boolean proximo;
        if (cursor == null) {
            return;
        } else {
            proximo = cursor.moveToFirst();
            while (proximo) {
                int id_serv_realizado = cursor.getInt(0);
                String nome_serv  = cursor.getString(1);
                int data_serv  = cursor.getInt(2);
                float  valor_unit = cursor.getFloat(3);
                float  valor_total = cursor.getFloat(4);
                float  qtd_serv   = cursor.getFloat(5);
                ServicosRealizados servicosRealizados = new ServicosRealizados(id_serv_realizado,nome_serv, data_serv, valor_unit, valor_total, qtd_serv);
                lista.add(servicosRealizados);
                proximo = cursor.moveToNext();
            }
        }cursor.close();
    }


    public void carregarServicos(ArrayList<Servicos> lista, int id_cat_serv) {
        lista.clear();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT nome_servicos FROM tb_servicos WHERE id_categoria_servicos = ?";

        String coluna[] = new String[1];
        coluna[0] = COLUNA_NOME_SERV;
        Cursor cursor = getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(id_cat_serv)});
        boolean proximo;
        if (cursor == null) {
            return;
        } else {
            proximo = cursor.moveToFirst();
            while (proximo) {
                String nome_serv = cursor.getString(0);
                Servicos servicos = new Servicos(nome_serv);
                lista.add(servicos);
                proximo = cursor.moveToNext();
            }
        }
    }

    //----------------------------------------------------------------------------------------------------------------
    public void carregarVeiculo(ArrayList<Veiculos> lista, String login, String senha) {
        lista.clear();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT placa_veiculo, modelo FROM tb_veiculo v " +
                                                    "JOIN tb_usuario u " +
                                                        "ON v.id_usuarios = u.id_usuarios"+
                                                         " WHERE u.login_usuario = ? AND senha_usuario = ?";

        String coluna[] = new String[2];
        coluna[0] = COLUNA_PLACA; coluna[1] = COLUNA_MODELO;
        Cursor cursor = getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(login),String.valueOf(senha)});
        boolean proximo;
        if (cursor == null) {
            return;
        } else {
            proximo = cursor.moveToFirst();
            while (proximo) {
                String placa = cursor.getString(0);
                String modelo = cursor.getString(1);
                Veiculos veiculos = new Veiculos(placa, modelo);
                lista.add(veiculos);
                proximo = cursor.moveToNext();
            }
        }cursor.close();
    }


//----------------------------------------------------------------------------------------------------------------

    public Fabricante selecionarFabricante(String nome_fab) {

        Fabricante fabricante = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM tb_fabricantes WHERE fab_nome = ?" ;

        Cursor cursor = db.rawQuery(sql,new String[]{String.valueOf(nome_fab)});

        if (cursor.moveToFirst()){

            int id_fab = cursor.getInt(cursor.getColumnIndex("id_fabricantes"));

            fabricante = new Fabricante();

            fabricante.setId_fabricante(id_fab);
            fabricante.setNome_fab(nome_fab);
        }


        return fabricante;
        }

    public Servicos selecionarServicos(String nome_serv) {

        Servicos servicos = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM tb_servicos WHERE nome_servicos = ?" ;

        Cursor cursor = db.rawQuery(sql,new String[]{String.valueOf(nome_serv)});

        if (cursor.moveToFirst()){

            int id_serv = cursor.getInt(cursor.getColumnIndex("id_servicos"));

            servicos = new Servicos();

            servicos.setId_servico(id_serv);
            servicos.setNome_servico(nome_serv);
        }


        return servicos;
    }

    public ServicosRealizados selecionarServicosRealizados(int id_cat_serv) {

        ServicosRealizados servicosRealizados = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM tb_servicos_realizados WHERE id_servicos = ?" ;

        Cursor cursor = db.rawQuery(sql,new String[]{String.valueOf(id_cat_serv)});

        if (cursor.moveToFirst()){

            int id_servicos = cursor.getInt(cursor.getColumnIndex("id_servicos"));

            servicosRealizados = new ServicosRealizados();

            servicosRealizados.setId_servico(id_servicos);
            servicosRealizados.setId_servico(id_cat_serv);
        }


        return servicosRealizados;
    }


    public Veiculos selecionarVeiculo(String placa) {

        Veiculos veiculos = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM tb_veiculo WHERE placa_veiculo = ?" ;

        Cursor cursor = db.rawQuery(sql,new String[]{String.valueOf(placa)});

        if (cursor.moveToFirst()){

            int id_veiculos = cursor.getInt(cursor.getColumnIndex("id_veiculos"));

            veiculos = new Veiculos();

            veiculos.setId_veiculos(id_veiculos);
            veiculos.setPlaca_veiculo(placa);
        }


        return veiculos;
    }

    public Veiculos selecionarVeiculoID(int id_veiculo) {

        Veiculos veiculos = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM tb_veiculo WHERE id_veiculos = ?" ;

        Cursor cursor = db.rawQuery(sql,new String[]{String.valueOf(id_veiculo)});

        if (cursor.moveToFirst()){

            String placa = cursor.getString( cursor.getColumnIndex("placa_veiculo"));
            String modelo = cursor.getString( cursor.getColumnIndex("modelo"));
            String ano_fab = cursor.getString( cursor.getColumnIndex("ano_fab"));

            veiculos = new Veiculos();

            veiculos.setId_veiculos(id_veiculo);
            veiculos.setPlaca_veiculo(placa);
            veiculos.setModelo(modelo);
            veiculos.setAno_fab(ano_fab);

        }


        return veiculos;
    }


    public Usuario selecionarUsuario(String login, String senha) {

        Usuario usuario = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM tb_usuario WHERE login_usuario = ? and senha_usuario = ?" ;

        Cursor cursor = db.rawQuery(sql,new String[]{String.valueOf(login),String.valueOf(senha)});

        if (cursor.moveToFirst()){

            int id_usuarios = cursor.getInt(cursor.getColumnIndex("id_usuarios"));
            String nome_usuario = cursor.getString(cursor.getColumnIndex("nome_usuario"));
            String email_usuario = cursor.getString(cursor.getColumnIndex("email_usuario"));

            usuario = new Usuario();

            usuario.setId_usuario(id_usuarios);
            usuario.setEmail_usuario(email_usuario);
            usuario.setNome_usuario(nome_usuario);
            usuario.setLogin_usuario(login);
            usuario.setSenha_usuario(senha);
        }


        return usuario;
    }
//----------------------------------------------------------------------------------------------------------------


    public void carregarFabricantes(ArrayList<Fabricante> lista) {
        lista.clear();
        SQLiteDatabase db = getReadableDatabase();
        String coluna[] = new String[1];
        coluna[0] = COLUNA_NOME_FAB;
        Cursor cursor = db.query(TABELA_FABRICANTES, coluna,
                null, null, null, null, null);
        boolean proximo;
        if (cursor == null) {
            return;
        } else {
            proximo = cursor.moveToFirst();
            while (proximo) {
                String nome_fab = cursor.getString(0);
                Fabricante fabricante = new Fabricante(nome_fab);
                lista.add(fabricante);
                proximo = cursor.moveToNext();
            }
        }
    }



    void apagarUsuario(Usuario usuario) {
        //FUNÇÃO PARA APAGAR USUARIO "CADASTRO"

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABELA_USUARIO, COLUNA_ID + " = ?", new String[]{String.valueOf(usuario.getId_usuario())});

        db.close();
    }

    public void apagarServicoRealizado(int id_serv_realizado) {
        //FUNÇÃO PARA APAGAR USUARIO "CADASTRO"

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABELA_SERV_REALIZADOS, COLUNA_ID_SERVICOS_REALIZADOS + " = ? ", new String[]{String.valueOf(id_serv_realizado)});

        db.close();
    }

    public void apagarServicoVeiculo(String placa) {
        //FUNÇÃO PARA APAGAR USUARIO "CADASTRO"

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABELA_VEICULO, COLUNA_PLACA + " = ? ", new String[]{String.valueOf(placa)});

        db.close();
    }



    void atualizaUsuario(Usuario usuario) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUNA_NOME, usuario.nome_usuario);
        values.put(COLUNA_CPF, usuario.cpf_usuario);
        values.put(COLUNA_EMAIL, usuario.email_usuario);
        values.put(COLUNA_LOGIN, usuario.login_usuario);
        values.put(COLUNA_SENHA, usuario.senha_usuario);

        db.update(TABELA_USUARIO, values, COLUNA_ID + " =?", new String[]{String.valueOf(usuario.getId_usuario())});
    }

    boolean validaSenha(String senha, String login) {
        //FUNÇÃO PARA VALIDAR O LOGIN

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT " + COLUNA_SENHA + ", " + COLUNA_LOGIN + " FROM " + TABELA_USUARIO + " WHERE " + COLUNA_SENHA + " = ? AND " + COLUNA_LOGIN + " = ?";
        String[] selectionArgs = new String[]{senha, login};
        Cursor cursor = getReadableDatabase().rawQuery(sql, selectionArgs);

        // Retorna se o cursor tem 1 resultado com o email e senha informados
        return cursor != null && cursor.getCount() == 1;
    }

    int recuperaIdFabricante(String nome_fabr) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT " + COLUNA_ID_FABRICANTES + " FROM " + TABELA_FABRICANTES + " WHERE " + COLUNA_NOME_FAB + " = ? GROUP BY " + COLUNA_ID_FABRICANTES;
        String[] selectionArgs = new String[]{nome_fabr};
        Cursor cursor = getReadableDatabase().rawQuery(sql, selectionArgs);
        return cursor.getInt(cursor.getColumnIndex(COLUNA_ID_FABRICANTES));
    }

    public String custoTotalServicos(int id_veic, int id_cat_serv){

        String sql = "SELECT SUM(valor_total_serv) as valor_total_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                " WHERE id_veiculos = "+id_veic+" AND id_categoria_servicos = " +id_cat_serv;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("valor_total_serv"));

        if (nomeString == null){
            nomeString = "0";
        }else{
            float custo = cursor.getFloat(cursor.getColumnIndex("valor_total_serv"));
            nomeString = String.valueOf(String.format("%.2f",custo));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }

    public String maxValorSubServicos(int id_veic, int id_serv){

        String sql = "SELECT MAX(valor_unit_serv) as valor_unit_serv FROM tb_servicos_realizados" +
                " WHERE id_veiculos = "+id_veic+" AND id_servicos = "+id_serv;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("valor_unit_serv"));

        if (nomeString == null){
            nomeString = "0";
        }else{
            float custo = cursor.getFloat(cursor.getColumnIndex("valor_unit_serv"));
            nomeString = String.valueOf(String.format("%.2f",custo));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }
    public String minValorSubServicos(int id_veic, int id_serv){

        String sql = "SELECT MIN(valor_unit_serv) as valor_unit_serv FROM tb_servicos_realizados" +
                " WHERE id_veiculos = "+id_veic+" AND id_servicos = "+id_serv;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("valor_unit_serv"));

        if (nomeString == null){
            nomeString = "0";
        }else{
            float custo = cursor.getFloat(cursor.getColumnIndex("valor_unit_serv"));
            nomeString = String.valueOf(String.format("%.2f",custo));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }
    public String medioValorSubServicos(int id_veic, int id_serv){

        String sql = "SELECT AVG(valor_unit_serv) as valor_unit_serv FROM tb_servicos_realizados" +
                " WHERE id_veiculos = "+id_veic+" AND id_servicos = "+id_serv;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("valor_unit_serv"));

        if (nomeString == null){
            nomeString = "0";
        }else{
            float custo = cursor.getFloat(cursor.getColumnIndex("valor_unit_serv"));
            nomeString = String.valueOf(String.format("%.2f",custo));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }

    public String TotalGasto(int id_veic){

        String sql = "SELECT SUM(valor_total_serv) as valor_total_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                " WHERE id_veiculos = "+id_veic;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("valor_total_serv"));

        if (nomeString == null){
            nomeString = "0";
        }else{
            float custo = cursor.getFloat(cursor.getColumnIndex("valor_total_serv"));
            nomeString = String.valueOf(String.format("%.2f",custo));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }

    public String custoMedioServicos(int id_veic, int id_cat_serv){

        String sql = "SELECT AVG(valor_unit_serv) as valor_unit_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                " WHERE id_veiculos = "+id_veic+" AND id_categoria_servicos = " +id_cat_serv;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("valor_unit_serv"));

        if (nomeString == null){
            nomeString = "0.00";
        }else{
            float custo = cursor.getFloat(cursor.getColumnIndex("valor_unit_serv"));
            nomeString = String.valueOf(String.format("%.2f",custo));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }

    public String quantidadeTotalServicos(int id_veic, int id_cat_serv){

        String sql = "SELECT SUM(qtd_serv) as qtd_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                " WHERE id_veiculos = "+id_veic+" AND id_categoria_servicos = " +id_cat_serv;


        SQLiteDatabase banco = this.getWritableDatabase();
        Cursor cursor = banco.rawQuery(sql, null);

        cursor.moveToFirst();

        String nomeString = cursor.getString(cursor.getColumnIndex("qtd_serv"));

        if (nomeString == null){
            nomeString = "0";
        }else{
            float qtd = cursor.getFloat(cursor.getColumnIndex("qtd_serv"));
            nomeString = String.valueOf(String.format("%.2f",qtd));
        }

        StringBuilder conversor = new StringBuilder();
        conversor.append(nomeString);
        return conversor.toString();

    }

    public void obterServicosRealizados(ArrayList<ServicosRealizados> lista, int id_cat_serv) {
        lista.clear();
        SQLiteDatabase db = getReadableDatabase();

        //String sql = "SELECT nome_servicos FROM tb_servicos WHERE id_categoria_servicos = ?";

        String sql = "SELECT nome_servicos, SUM(valor_total_serv) as valor_total_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                " WHERE id_categoria_servicos = ?"+
                " GROUP BY nome_servicos;";

        Cursor cursor = getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(id_cat_serv)});
        boolean proximo;
        if (cursor == null) {
            return;
        } else {
            proximo = cursor.moveToFirst();
            while (proximo) {
                String nome_serv = cursor.getString(0); float valorTotal = cursor.getFloat(1);
                ServicosRealizados servicosRealizados = new ServicosRealizados(nome_serv,valorTotal);
                lista.add(servicosRealizados);
                proximo = cursor.moveToNext();
            }
        }
    }

    public ArrayList<PieEntry> getPieEntries(int id_veic, int id_cat, int data_min, int data_max) {
        String valorTotal_sum = "valor_total_serv";
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT nome_servicos, SUM(valor_total_serv) as valor_total_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                " WHERE id_veiculos = "+ id_veic +" AND id_categoria_servicos = "+id_cat+
                        " AND (data_serv BETWEEN "+data_min+" AND "+data_max+" )" +
                " GROUP BY nome_servicos;";

        Cursor csr = getReadableDatabase().rawQuery(sql,null);

        ArrayList<PieEntry> rv = new ArrayList<>();
        while (csr.moveToNext()) {
            rv.add(new PieEntry(
                    csr.getFloat(csr.getColumnIndex(valorTotal_sum)),
                    csr.getString(csr.getColumnIndex("nome_servicos"))

            ));
        }
        csr.close();
        return rv;
    }
// FUNCIONANDOOOOOOOO----------------------------------------------------------------------------------------------------


     public ArrayList<PieEntry> getPieEntries2(int id_veic, int data_min, int data_max) {
        String valorTotal_sum = "valor_total_serv";
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT nome_cat_servicos, SUM(valor_total_serv) as valor_total_serv FROM tb_servicos v " +
                "JOIN tb_servicos_realizados u " + "ON v.id_servicos = u.id_servicos "+
                "JOIN tb_categoria_servicos c "  + "ON c.id_categoria_servicos = v.id_categoria_servicos "+
                " WHERE id_veiculos = "+ id_veic + " AND (data_serv BETWEEN "+data_min+" AND "+data_max+" )"+
                " GROUP BY nome_cat_servicos;";

        Cursor csr = getReadableDatabase().rawQuery(sql,null);

        ArrayList<PieEntry> rv = new ArrayList<>();
        while (csr.moveToNext()) {
            rv.add(new PieEntry(
                    csr.getFloat(csr.getColumnIndex(valorTotal_sum)),
                    csr.getString(csr.getColumnIndex("nome_cat_servicos"))

            ));
        }
        csr.close();
        return rv;
    }

//FUNCIONANDOOOOOOOO----------------------------------------------------------------------------------------------------



}