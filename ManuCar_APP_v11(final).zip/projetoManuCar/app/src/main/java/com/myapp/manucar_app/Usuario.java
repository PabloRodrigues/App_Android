package com.myapp.manucar_app;

public class Usuario {

    int id_usuario;
    String nome_usuario;
    String cpf_usuario;
    String email_usuario;
    String login_usuario;
    String senha_usuario;

    public int usuarioLogado(String login_usuario, String senha_usuario){
        return id_usuario;
    }

    public Usuario(){
        //construtor vazio
    }

    public Usuario(int _id_usuario, String _nome_usuario, String _cpf_usuario,String _email_usuario, String _login_usuario, String _senha_usuario ){
        //construtor para update
        this.id_usuario     = _id_usuario;
        this.nome_usuario   = _nome_usuario;
        this.cpf_usuario    = _cpf_usuario;
        this.email_usuario  = _email_usuario;
        this.login_usuario  = _login_usuario;
        this.senha_usuario  = _senha_usuario;

    }

    public Usuario(int _id_usuario) {
        //construtor para get s/ login e senha
        this.id_usuario = _id_usuario;
    }

    public Usuario(String _nome_usuario, String _cpf_usuario,String _email_usuario, String _login_usuario, String _senha_usuario ){
        //construtor para insert
        this.nome_usuario   = _nome_usuario;
        this.cpf_usuario    = _cpf_usuario;
        this.email_usuario  = _email_usuario;
        this.login_usuario  = _login_usuario;
        this.senha_usuario  = _senha_usuario;
    }

    public Usuario(int _id_usuario, String _nome_usuario, String _cpf_usuario,String _email_usuario){
        //construtor para get s/ login e senha
        this.id_usuario     = _id_usuario;
        this.nome_usuario   = _nome_usuario;
        this.cpf_usuario    = _cpf_usuario;
        this.email_usuario  = _email_usuario;
    }




    // GET AND SETTERS ----------------------------------------------------------------------------------------------------------------------
    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNome_usuario() {
        return nome_usuario;
    }

    public void setNome_usuario(String nome_usuario) {
        this.nome_usuario = nome_usuario;
    }

    public String getCpf_usuario() {
        return cpf_usuario;
    }

    public void setCpf_usuario(String cpf_usuario) {
        this.cpf_usuario = cpf_usuario;
    }

    public String getEmail_usuario() {
        return email_usuario;
    }

    public void setEmail_usuario(String email_usuario) {
        this.email_usuario = email_usuario;
    }

    public String getLogin_usuario() {
        return login_usuario;
    }

    public void setLogin_usuario(String login_usuario) {
        this.login_usuario = login_usuario;
    }

    public String getSenha_usuario() {
        return senha_usuario;
    }

    public void setSenha_usuario(String senha_usuario) {
        this.senha_usuario = senha_usuario;
    }
// GET AND SETTERS ----------------------------------------------------------------------------------------------------------------------


}
