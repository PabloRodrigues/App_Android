package com.myapp.manucar_app.ui.oleo;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;
import com.myapp.manucar_app.BancoDados;
import com.myapp.manucar_app.R;
import com.myapp.manucar_app.Servicos;
import com.myapp.manucar_app.ServicosRealizados;
import com.myapp.manucar_app.ui.allServs.ListServsFragment;

public class OleoFragment extends Fragment {

    int id_usuario;
    int id_veiculo;
    final int id_cat_serv = 4;
    EditText precoLitro;
    EditText litros;
    TextView valorTotal;

    BancoDados bancoDados;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_oleo, container, false);

        bancoDados = new BancoDados(getContext());

// inicia itens da tela========================================================================================================
        final EditText dataAbastecimento     = root.findViewById(R.id.dataAbastecimento_editText);
        precoLitro            = root.findViewById(R.id.precoUnit_editText);
        litros                = root.findViewById(R.id.litros_editText);
        final EditText odometro              = root.findViewById(R.id.odometro_editText);
        final EditText posto                 = root.findViewById(R.id.posto_editText);
        valorTotal            = root.findViewById(R.id.valorTotal_textView);
        Button addOleo_button       = root.findViewById(R.id.addOleo_button);

        //criando mascara de data==============================================
        SimpleMaskFormatter smf = new SimpleMaskFormatter("NN/NN/NNNN");
        MaskTextWatcher mtw = new MaskTextWatcher(dataAbastecimento,smf);
        dataAbastecimento.addTextChangedListener(mtw);
        //criando mascara de data==============================================
// inicia itens da tela========================================================================================================
//FUNÇÃO DO BOTÃO ADICIONAR ABASTECIMENTO===========================================================================================================================
        addOleo_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String dataServ = dataAbastecimento.getText().toString();;
                String valorUnit = precoLitro.getText().toString();
                //String valorTotalTemp = valorTotal.getText().toString().trim();
                String qtdServTemp = litros.getText().toString();
                String odometroTemp = odometro.getText().toString();
                String razaoSocialServ = posto.getText().toString();

                String serv_temp = "Troca de Óleo";


                if(dataServ.isEmpty()){
                    dataAbastecimento.setError("Este campo é obrigatorio");
                }else if(valorUnit.isEmpty()){
                    precoLitro.setError("Este campo é obrigatorio");
                }else if(qtdServTemp.isEmpty()){
                    litros.setError("Este campo é obrigatorio");
                }else if(odometroTemp.isEmpty()){
                    odometro.setError("Este campo é obrigatorio");
                }else if(razaoSocialServ.isEmpty()){
                    posto.setError("Este campo é obrigatorio");
                }else{
                    float valorUnitario = Float.parseFloat(valorUnit);
                    float qtdServ = Float.parseFloat(qtdServTemp);
                    float valorTotal = valorUnitario * qtdServ;
                    int odometroServ = Integer.parseInt(odometroTemp);
                    String dataTemp = dataServ.substring(6, 10)+""+dataServ.substring(3, 5)+""+dataServ.substring(0,2);//Transforma a data em YYYYmmDD (String)
                    int dataINT = Integer.parseInt(dataTemp);// transformo data YYYYmmDD em int

                    Servicos servicos1 = bancoDados.selecionarServicos(serv_temp);
                    int id_servicos = servicos1.getId_servico();

                    bancoDados.addServicoRealizado(new ServicosRealizados(dataINT,valorUnitario,valorTotal,qtdServ,odometroServ,razaoSocialServ,id_servicos,id_veiculo));
//========================================================================================
                    Fragment fragment;
                    fragment = new ListServsFragment();
                    //fragment = new CombustivelFragment();
                    //==============================================================================================
                    int id_cat_servico = 4;
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico", id_cat_servico);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();
//========================================================================================
                }
//FUNÇÃO DO BOTÃO ADICIONAR ABASTECIMENTO===========================================================================================================================
            }
        });

//recupera os dados passados por argumentos da mainActivity===========================================================
        Bundle bundle = getArguments();
        if (bundle != null) {
            id_usuario = bundle.getInt("id_usuario");
            id_veiculo = bundle.getInt("id_veiculo");
        }
//recupera os dados passados por argumentos da mainActivity===========================================================

//ATUALIZA O CAMPO VALOR TOTAL AUTOMATICAMENTE==================================================
        litros.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do some thing now
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                Float preco = 0f;
                Float q = 0f;

                String stringPreco = precoLitro.getText().toString().trim();
                if(!stringPreco.equals("")){
                    preco = Float.valueOf(stringPreco);
                }
                String stringS = s.toString().trim();
                if(!stringS.equals("")){
                    q = Float.valueOf(stringS);
                }
                Float total = (q * preco);
                valorTotal.setText(total.toString());
            }
        });
//ATUALIZA O CAMPO VALOR TOTAL AUTOMATICAMENTE=================================================


        return root;
    }



    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {

        } else {
            getFragmentManager().popBackStack();
        }
    }

}