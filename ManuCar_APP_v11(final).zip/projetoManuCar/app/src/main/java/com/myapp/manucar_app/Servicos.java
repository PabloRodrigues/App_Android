package com.myapp.manucar_app;

public class Servicos {

    int id_servico;
    String nome_servico;
    int id_cat_serv;

    public Servicos() {
    }

    public Servicos(String nome_servico) {
        this.nome_servico = nome_servico;
    }

    public int getId_servico() {
        return id_servico;
    }

    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    public String getNome_servico() {
        return nome_servico;
    }

    public void setNome_servico(String nome_servico) {
        this.nome_servico = nome_servico;
    }

    public int getId_cat_serv() {
        return id_cat_serv;
    }

    public void setId_cat_serv(int id_cat_serv) {
        this.id_cat_serv = id_cat_serv;
    }

    @Override
    public String toString() {
        return  nome_servico ;
    }
}
