package com.myapp.manucar_app.ui.despesas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;
import com.myapp.manucar_app.BancoDados;
import com.myapp.manucar_app.R;
import com.myapp.manucar_app.Servicos;
import com.myapp.manucar_app.ServicosRealizados;
import com.myapp.manucar_app.ui.allServs.ListServsFragment;

import java.util.ArrayList;

public class DespesasFragment extends Fragment {

    int id_usuario;
    int id_veiculo;
    final int id_cat_serv = 3;
    EditText valorTotal;

    private ArrayList<Servicos> lista;
    private ArrayAdapter<Servicos> adapter;

    BancoDados bancoDados;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_despesas, container, false);

        bancoDados = new BancoDados(getContext());

// inicia itens da tela================================================================
        final EditText dataAbastecimento     = root.findViewById(R.id.dataAbastecimento_editText);
        final EditText tipoDespesa       = root.findViewById(R.id.tipoDespesa_editText);
        valorTotal            = root.findViewById(R.id.valorTotal_editText);
        final EditText odometro              = root.findViewById(R.id.odometro_editText);
        final EditText local                 = root.findViewById(R.id.local_editText);

        Button addServicos_button       = root.findViewById(R.id.addDespesas_button);

        //criando mascara de data==============================================
        SimpleMaskFormatter smf = new SimpleMaskFormatter("NN/NN/NNNN");
        MaskTextWatcher mtw = new MaskTextWatcher(dataAbastecimento,smf);
        dataAbastecimento.addTextChangedListener(mtw);
        //criando mascara de data==============================================


//listView para seleção do serviço no dialog===============================================================================================
        ListView listaListView = new ListView(getContext());
        lista = new ArrayList<Servicos>();
        adapter = new ArrayAdapter<Servicos>(getContext(),
                android.R.layout.simple_expandable_list_item_1,
                lista);
        listaListView.setAdapter(adapter);

        //cria o dialogo
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setCancelable(true);
        builder.setView(listaListView);
        final AlertDialog dialog =builder.create();

        //função do botão fabricante para abrir as opções
        tipoDespesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bancoDados.carregarServicos(lista, id_cat_serv);
                adapter.notifyDataSetChanged();
                dialog.show();
            }
        });

        //função de click nos item da lista para salvar no editText
        listaListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                tipoDespesa.setText(adapter.getItem(position).toString());
                dialog.dismiss();
            }
        });
//listView para seleção do serviço no dialog===============================================================================================

//FUNÇÃO DO BOTÃO ADICIONAR ABASTECIMENTO===========================================================================================================================
        addServicos_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String dataServ = dataAbastecimento.getText().toString();;
                String valorUnit = valorTotal.getText().toString();

                String qtdServTemp = "1";
                String odometroTemp = odometro.getText().toString();
                String razaoSocialServ = local.getText().toString();

                String serv_temp = tipoDespesa.getText().toString();


                if(dataServ.isEmpty()){
                    dataAbastecimento.setError("Este campo é obrigatorio");
                }else if(valorUnit.isEmpty()){
                    valorTotal.setError("Este campo é obrigatorio");
                }else if(odometroTemp.isEmpty()){
                    odometro.setError("Este campo é obrigatorio");
                }else if(razaoSocialServ.isEmpty()){
                    local.setError("Este campo é obrigatorio");
                }else{
                    float valorUnitario = Float.parseFloat(valorUnit);
                    float qtdServ = Float.parseFloat(qtdServTemp);
                    float valorTotal = valorUnitario;
                    int odometroServ = Integer.parseInt(odometroTemp);
                    String dataTemp = dataServ.substring(6, 10)+""+dataServ.substring(3, 5)+""+dataServ.substring(0,2);//Transforma a data em YYYYmmDD (String)
                    int dataINT = Integer.parseInt(dataTemp);// transformo data YYYYmmDD em int

                    Servicos servicos1 = bancoDados.selecionarServicos(serv_temp);
                    int id_servicos = servicos1.getId_servico();

                    bancoDados.addServicoRealizado(new ServicosRealizados(dataINT,valorUnitario,valorTotal,qtdServ,odometroServ,razaoSocialServ,id_servicos,id_veiculo));
//========================================================================================
                    Fragment fragment;
                    fragment = new ListServsFragment();
                    //fragment = new CombustivelFragment();
                    //==============================================================================================
                    int id_cat_servico = 3;
                    Bundle bundle = new Bundle();
                    bundle.putInt("id_cat_servico", id_cat_servico);
                    bundle.putInt("id_usuario", id_usuario);
                    bundle.putInt("id_veiculo", id_veiculo);
                    fragment.setArguments(bundle);
                    //==============================================================================================
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    ft.replace(R.id.mainFrame, fragment);
                    ft.commit();
//========================================================================================
                }
//FUNÇÃO DO BOTÃO ADICIONAR ABASTECIMENTO===========================================================================================================================
            }
        });

//recupera os dados passados por argumentos da mainActivity===========================================================
        Bundle bundle = getArguments();
        if (bundle != null) {
            id_usuario = bundle.getInt("id_usuario");
            id_veiculo = bundle.getInt("id_veiculo");
        }
//recupera os dados passados por argumentos da mainActivity===========================================================

        return root;
    }

    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {

        } else {
            getFragmentManager().popBackStack();
        }
    }
}