package com.myapp.manucar_app.ui.resumo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.myapp.manucar_app.BancoDados;
import com.myapp.manucar_app.R;
import com.myapp.manucar_app.Veiculos;

public class ResumoFragment extends Fragment {

    int id_usuario;
    int id_veiculo;
    //veiculo
    TextView dadosVeic;
    TextView totalGastoVeic;
//combustivel
    // gasolina
    TextView precoMinGasolina;
    TextView precoMaxGasolina;
    TextView precoMedioGasolina;
    //Etanol
    TextView precoMinEtanol;
    TextView precoMaxEtanol;
    TextView precoMedioEtanol;
    //Diesel
    TextView precoMinDiesel;
    TextView precoMaxDiesel;
    TextView precoMedioDiesel;
    //Gas.Aditiv.
    TextView precoMinGasAditiv;
    TextView precoMaxGasAditiv;
    TextView precoMedioGasAditiv;
    //GNV
    TextView precoMinGNV;
    TextView precoMaxGNV;
    TextView precoMedioGNV;
    //Gas.Alta Oct.
    TextView precoMinGasAltaOct;
    TextView precoMaxMinGasAltaOct;
    TextView precoMedioMinGasAltaOct;
    //Etanol Aditiv
    TextView precoMinEtanolAdt;
    TextView precoMaxEtanolAdt;
    TextView precoMedioEtanolAdt;
 //combustivel
    //óleo
    TextView custoTotalOleo;
    TextView litrosOleo;
    TextView precoMedioOleo;
    //serviços
    TextView custoTotalServicos;
    TextView freqServicos;
    //despesas
    TextView custoTotalDespesas;
    TextView freqDespesas;
    //seguros
    TextView custoTotalSeguro;


    BancoDados bancoDados;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_resumo, container, false);
        bancoDados = new BancoDados(getContext());

        dadosVeic = root.findViewById(R.id.dados_veic_textView);
        totalGastoVeic = root.findViewById(R.id.total_gasto_veic_textView);
        custoTotalOleo = root.findViewById(R.id.custoTotalOleo_textView);
        litrosOleo = root.findViewById(R.id.litrosOleo_textView);
        precoMedioOleo = root.findViewById(R.id.precoMedioOleo_textView2);
        custoTotalServicos = root.findViewById(R.id.custoTotalServ_textView3);
        freqServicos = root.findViewById(R.id.freqServicos_textView4);
        custoTotalDespesas = root.findViewById(R.id.custoTotalDesp_textView7);
        freqDespesas = root.findViewById(R.id.freqDesp_textView8);
        custoTotalSeguro = root.findViewById(R.id.custoTotalSeguro_textView5);

        //combustivel
        precoMinGasolina        = root.findViewById(R.id.precoMinGaso_txt);
        precoMaxGasolina        = root.findViewById(R.id.precoMaxGaso_txt);
        precoMedioGasolina      = root.findViewById(R.id.precoMedGaso_txt);

        precoMinEtanol          = root.findViewById(R.id.precoMinEtanol_txt);
        precoMaxEtanol          = root.findViewById(R.id.precoMaxEta_txt);
        precoMedioEtanol        = root.findViewById(R.id.precoMedEta_txt);

        precoMinDiesel          = root.findViewById(R.id.precoMinDiesel_txt);
        precoMaxDiesel          = root.findViewById(R.id.precoMaxDiesel_txt);
        precoMedioDiesel        = root.findViewById(R.id.precoMedDiesel_txt);

        precoMinGasAditiv       = root.findViewById(R.id.precoMinGasAdt_txt);
        precoMaxGasAditiv       = root.findViewById(R.id.precoMaxGasAdt_txt);
        precoMedioGasAditiv     = root.findViewById(R.id.precoMedGasAdt_txt);

        precoMinGNV             = root.findViewById(R.id.precoMinGNV_txt);
        precoMaxGNV             = root.findViewById(R.id.precoMaxGNV_txt);
        precoMedioGNV           = root.findViewById(R.id.precoMedGNV_txt);

        precoMinGasAltaOct      = root.findViewById(R.id.precoMinGasAltOc_txt);
        precoMaxMinGasAltaOct   = root.findViewById(R.id.precoMaxGasAltOc_txt);
        precoMedioMinGasAltaOct = root.findViewById(R.id.precoMedGasAltOct_txt);

        precoMinEtanolAdt       = root.findViewById(R.id.precoMinEtanolAdt_txt);
        precoMaxEtanolAdt       = root.findViewById(R.id.precoMaxEtanolAdt_txt);
        precoMedioEtanolAdt     = root.findViewById(R.id.precoMedEtaAdtv_txt1);

        //combustivel

//recupera os dados passados por argumentos da mainActivity===========================================================
        Bundle bundle = getArguments();
        if (bundle != null) {
            id_usuario = bundle.getInt("id_usuario");
            id_veiculo = bundle.getInt("id_veiculo");
        }
//recupera os dados passados por argumentos da mainActivity===========================================================
        Veiculos veiculos1 = bancoDados.selecionarVeiculoID(id_veiculo);
        dadosVeic.setText(veiculos1.getPlaca_veiculo()+" - "+veiculos1.getModelo()+" - "+veiculos1.getAno_fab());
        totalGastoVeic.setText("R$: "+bancoDados.TotalGasto(id_veiculo));

        custoTotalServicos.setText("R$: "+bancoDados.custoTotalServicos(id_veiculo,2));
        custoTotalDespesas.setText("R$: "+bancoDados.custoTotalServicos(id_veiculo,3));
        custoTotalOleo.setText("R$: "+bancoDados.custoTotalServicos(id_veiculo,4));
        custoTotalSeguro.setText("R$: "+bancoDados.custoTotalServicos(id_veiculo,5));

        freqServicos.setText(bancoDados.quantidadeTotalServicos(id_veiculo,2));
        freqDespesas.setText(bancoDados.quantidadeTotalServicos(id_veiculo,3));
        litrosOleo.setText(bancoDados.quantidadeTotalServicos(id_veiculo,4));

        precoMedioOleo.setText("R$: "+bancoDados.custoMedioServicos(id_veiculo,4));

        precoMinGasolina.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,1));
        precoMaxGasolina.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,1));
        precoMedioGasolina.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,1));

        precoMinEtanol.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,2));
        precoMaxEtanol.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,2));
        precoMedioEtanol.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,2));

        precoMinDiesel.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,3));
        precoMaxDiesel.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,3));
        precoMedioDiesel.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,3));

        precoMinGasAditiv.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,4));
        precoMaxGasAditiv.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,4));
        precoMedioGasAditiv.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,4));

        precoMinGNV.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,5));
        precoMaxGNV.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,5));
        precoMedioGNV.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,5));

        precoMinGasAltaOct.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,6));
        precoMaxMinGasAltaOct.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,6));
        precoMedioMinGasAltaOct.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,6));

        precoMinEtanolAdt.setText("R$: "+bancoDados.minValorSubServicos(id_veiculo,7));
        precoMaxEtanolAdt.setText("R$: "+bancoDados.maxValorSubServicos(id_veiculo,7));
        precoMedioEtanolAdt.setText("R$: "+bancoDados.medioValorSubServicos(id_veiculo,7));

        return root;
    }
}