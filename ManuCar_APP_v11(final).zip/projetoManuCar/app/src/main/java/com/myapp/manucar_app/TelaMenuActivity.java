package com.myapp.manucar_app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class TelaMenuActivity extends AppCompatActivity implements View.OnClickListener {

    private Button adcCarroButton;

    private ListView listaListView;
    private ArrayList<Veiculos> lista;
    private ArrayAdapter<Veiculos> listaArrayAdapter;
    private BancoDados bancoDados;

    private int id_usuario;

    String loginIT;//recebe tanto da acitvity Login qnto RegistroVeiculo
    String senhaIT;//recebe tanto da acitvity Login qnto RegistroVeiculo


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_menu);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        bancoDados = new BancoDados(this);
        adcCarroButton = findViewById(R.id.adcCarroButton);
        adcCarroButton.setOnClickListener(this);

        ////////////////////////////////////////////////////////
        listaListView = findViewById(R.id.ID1_LISTAListView);
        lista = new ArrayList<Veiculos>();
        listaArrayAdapter = new ArrayAdapter<Veiculos>(this,
                R.layout.list_item_text,
                lista);
        listaListView.setAdapter(listaArrayAdapter);
        listaListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//passar os dados do veiculo e do usuario para as manutenções===========================================================================
                String placa = listaArrayAdapter.getItem(position).getPlaca_veiculo();
                Veiculos veiculos1 = bancoDados.selecionarVeiculo(placa);
                int id_veiculo = veiculos1.getId_veiculos();

                Intent intentMain = new Intent(TelaMenuActivity.this, MainActivity.class);

                Usuario usuario1 = bancoDados.selecionarUsuario(loginIT, senhaIT);
                int id_usuario = usuario1.getId_usuario();

                Bundle extrasMenu = new Bundle();
                extrasMenu.putString("loginIT2",loginIT);
                extrasMenu.putString("senhaIT2",senhaIT);
                extrasMenu.putInt("id_usuario",id_usuario);
                extrasMenu.putInt("id_veiculo",id_veiculo);

                intentMain.putExtras(extrasMenu);
                startActivity(intentMain);


//passar os dados do veiculo e do usuario para as manutenções==============================================================================
            }
        });
        listaListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TelaMenuActivity.this);
                builder.setTitle("Deseja cancelar o registro?");

                builder.setPositiveButton("OK",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        String placa = listaArrayAdapter.getItem(position).getPlaca_veiculo();
                        bancoDados.apagarServicoVeiculo(placa);
                        lista.remove(position);
                        listaArrayAdapter.notifyDataSetChanged();
                    }
                });

                builder.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                builder.show();

                return true;
            }
        });
        ///////////////////////////////////////////////////////////////
            //RECUPERA  INFORMAÇÕES DA INTENT MAIN ATRAVES DO BUNDLES.------------------------------------------------------------------------
            Intent intentLogin = getIntent();
            Bundle extrasLogin = intentLogin.getExtras();
            loginIT = extrasLogin.getString("LOGIN");
            senhaIT = extrasLogin.getString("SENHA");

            if (loginIT == null && senhaIT == null){
                loginIT = extrasLogin.getString("loginIT1");
                senhaIT = extrasLogin.getString("senhaIT1");
                //recupera o login e senha enviado para RegistroVeiculo
            }
            //RECUPERA  INFORMAÇÕES DA INTENT MAIN ATRAVES DO BUNDLES.------------------------------------------------------------------------

        bancoDados.carregarVeiculo(lista,loginIT,senhaIT);
        //Toast.makeText(TelaMenuActivity.this,"login: "+loginIT+" - senha: "+senhaIT ,Toast.LENGTH_LONG).show();
        listaArrayAdapter.notifyDataSetChanged();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.adcCarroButton:

                Intent intentMenu = new Intent(getApplicationContext(), TelaRegistroVeiculoActivity.class);

                Bundle extrasMenu = new Bundle();
                extrasMenu.putString("loginIT",loginIT);
                extrasMenu.putString("senhaIT",senhaIT);

                intentMenu.putExtras(extrasMenu);
                startActivity(intentMenu);
                //PASSA O ID DO USUARIO LOGADO PARA REGISTRO DO VEICULO---------------------------------------------------------------------------
                break;

        }
    }


}
